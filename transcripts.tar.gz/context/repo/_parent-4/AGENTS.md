# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- **On-chain price accuracy (standing rule, 2026-10-30):** for every NFT listing or marketplace transaction, identify chain, payment token, decimals (verified from the contract, never assumed) and marketplace ABI; convert prices with BigInt only, never floats; simulate and decode the encoded price back to human units BEFORE signing, and require an exact match with the user's requested price and currency — otherwise STOP. Full text in `~/workspace/custom-skills/onchain-price-accuracy/SKILL.md`. This rule was added after a Wuse $8 draft was caught at ~$7.84 and corrected before signing.
- **Historical eth_getLogs on BSC (2026-11-01):** dataseed endpoints block eth_getLogs entirely ("limit exceeded" even for 10-block ranges); 48.club caps ranges at 5000 blocks and fails old headers ("header not found"); the Lab site's own public RPC (from its public config.js) works for full-history scans. Never persist that endpoint's key in files; pass it via env at runtime only.
- **WBNB address (fixed 2026-11-15):** correct is `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` (ends `...095c`). I kept hand-typing `...9173bc281` (41 chars, INVALID) — it made every `factory.getPair` call fail with a misleading "missing revert data" / "cannot slice beyond data bounds" error instead of an invalid-address error. Same bug class as the TANK 39-char truncation. RULE: never retype an address by hand — copy it from a verified file (seal-check-2026-11-14.mjs holds the correct WBNB) and length-check EVERY 0x address in a script before running it.

- **Robinhood Chain RPC (corrected 2026-11-13 ~00:38):** official RH RPC https://rpc.mainnet.chain.robinhood.com IS reachable from the VM (chainId 4663 confirmed); probe script ~/workspace/computeroll/rh-check.mjs. Earlier note (2026-11-12 ~07:30) that RH RPCs/explorer were unreachable is outdated. Efendi's RH ETH balance re-confirmed 0 on-chain at the same time.
